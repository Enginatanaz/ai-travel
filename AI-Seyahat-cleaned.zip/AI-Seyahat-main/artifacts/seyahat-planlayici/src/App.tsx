import { useMemo, useState, type FormEvent } from 'react';
import type { TravelPlan } from '@workspace/api-client-react';
import { TravelPlanResult } from '@/components/travel-plan-result';
import {
  ArrowRight,
  BedDouble,
  BusFront,
  CalendarDays,
  Check,
  ChevronDown,
  CircleAlert,
  Clock3,
  Compass,
  Footprints,
  Heart,
  Info,
  MapPin,
  Moon,
  Navigation,
  Plus,
  Route,
  Sparkles,
  SunMedium,
  TrainFront,
  Users,
  WalletCards,
  X,
} from 'lucide-react';

type Option = { value: string; label: string; note?: string };
type Preferences = {
  travelers: string;
  accommodation: string;
  startTime: string;
  endTime: string;
  walking: string;
};

const interests: Option[] = [
  { value: 'kultur', label: 'Kültür & tarih' },
  { value: 'yemek', label: 'Yerel lezzetler' },
  { value: 'doga', label: 'Doğa & manzara' },
  { value: 'deniz', label: 'Deniz & sahil' },
  { value: 'sanat', label: 'Sanat & tasarım' },
  { value: 'gece', label: 'Gece hayatı' },
];

const budgets: Option[] = [
  { value: 'ekonomik', label: 'Ekonomik', note: 'Temel konfor, akıllı seçimler' },
  { value: 'dengeli', label: 'Dengeli', note: 'Konfor ve keşif arasında' },
  { value: 'rahat', label: 'Rahat', note: 'Daha fazla esneklik ve konfor' },
];

const transport: Option[] = [
  { value: 'yuruyus', label: 'Yürüyüş ağırlıklı', note: 'Şehri adım adım keşfet' },
  { value: 'toplu', label: 'Toplu taşıma', note: 'Yerel ritme karış' },
  { value: 'arac', label: 'Araç / kiralık araç', note: 'Uzakları da programa kat' },
];

const initialPreferences: Preferences = {
  travelers: '2',
  accommodation: '',
  startTime: '09:00',
  endTime: '22:00',
  walking: 'orta',
};

function Logo() {
  return (
    <div className="flex items-center gap-3" data-testid="brand-mark">
      <div className="relative flex size-10 items-center justify-center rounded-[13px] bg-[#f5cf55] text-[#164b4a] shadow-[4px_4px_0_#164b4a]">
        <Compass size={22} strokeWidth={2.4} />
        <span className="absolute -right-1 -top-1 size-2 rounded-full bg-[#d66f4e]" />
      </div>
      <div className="leading-none">
        <div className="font-display text-[20px] font-bold tracking-[-0.05em] text-[#164b4a]">yolüstü</div>
        <div className="mt-1 font-mono-ui text-[8px] uppercase tracking-[0.22em] text-[#64817a]">iyi fikirler haritası</div>
      </div>
    </div>
  );
}

function SectionHeading({
  number,
  eyebrow,
  title,
  hint,
}: {
  number: string;
  eyebrow: string;
  title: string;
  hint?: string;
}) {
  return (
    <div className="mb-6 flex gap-4">
      <div className="font-mono-ui pt-1 text-[11px] font-medium tracking-[0.16em] text-[#d66f4e]">{number}</div>
      <div>
        <div className="mb-1 font-mono-ui text-[10px] font-medium uppercase tracking-[0.16em] text-[#64817a]">{eyebrow}</div>
        <h2 className="font-display text-[22px] font-bold tracking-[-0.035em] text-[#164b4a]">{title}</h2>
        {hint && <p className="mt-1 text-[13px] leading-5 text-[#6a817c]">{hint}</p>}
      </div>
    </div>
  );
}

function ChoiceButton({
  selected,
  label,
  note,
  onClick,
  testId,
  icon,
}: {
  selected: boolean;
  label: string;
  note?: string;
  onClick: () => void;
  testId: string;
  icon?: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      data-testid={testId}
      aria-pressed={selected}
      className={`group relative flex min-h-[68px] w-full items-center gap-3 rounded-[14px] border px-4 text-left transition duration-200 ${
        selected
          ? 'border-[#26726a] bg-[#e4f0e9] text-[#164b4a] shadow-[inset_0_0_0_1px_#26726a]'
          : 'border-[#dddccf] bg-[#fbfaf5] text-[#365957] hover:-translate-y-0.5 hover:border-[#8eaea0] hover:bg-[#f5f3e9]'
      }`}
    >
      {icon && (
        <span className={`flex size-9 shrink-0 items-center justify-center rounded-xl ${selected ? 'bg-[#26726a] text-[#f8f3e3]' : 'bg-[#e9eee5] text-[#50817a]'}`}>
          {icon}
        </span>
      )}
      <span className="min-w-0 flex-1">
        <span className="block text-[13px] font-semibold">{label}</span>
        {note && <span className="mt-0.5 block text-[11px] leading-4 text-[#78908a]">{note}</span>}
      </span>
      <span className={`flex size-5 shrink-0 items-center justify-center rounded-full border transition ${selected ? 'border-[#26726a] bg-[#26726a] text-[#fff8ea]' : 'border-[#b8c9be] text-transparent'}`}>
        <Check size={12} strokeWidth={3} />
      </span>
    </button>
  );
}

function FieldLabel({ children, required = false }: { children: React.ReactNode; required?: boolean }) {
  return (
    <div className="mb-2 flex items-center gap-1 text-[12px] font-semibold text-[#365957]">
      {children}
      {required && <span className="text-[#d66f4e]">*</span>}
    </div>
  );
}

function Home() {
  const [destinations, setDestinations] = useState<string[]>([]);
  const [destinationInput, setDestinationInput] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [budget, setBudget] = useState('');
  const [transportation, setTransportation] = useState('');
  const [preferences, setPreferences] = useState<Preferences>(initialPreferences);
  const [showPreferences, setShowPreferences] = useState(false);
  const [plan, setPlan] = useState<TravelPlan | null>(null);
  const [requestError, setRequestError] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [attempted, setAttempted] = useState(false);

  const requiredComplete = destinations.length > 0 && Boolean(startDate) && Boolean(endDate) && selectedInterests.length > 0 && Boolean(budget) && Boolean(transportation);
  const dateError = Boolean(startDate && endDate && endDate < startDate);
  const completionCount = useMemo(() => [destinations.length > 0, Boolean(startDate && endDate), selectedInterests.length > 0, Boolean(budget), Boolean(transportation)].filter(Boolean).length, [destinations, startDate, endDate, selectedInterests, budget, transportation]);

  const addDestination = () => {
    const value = destinationInput.trim();
    if (!value || destinations.some((item) => item.toLocaleLowerCase('tr-TR') === value.toLocaleLowerCase('tr-TR'))) return;
    setDestinations((current) => [...current, value]);
    setDestinationInput('');
  };

  const removeDestination = (destination: string) => {
    setDestinations((current) => current.filter((item) => item !== destination));
  };

  const toggleInterest = (value: string) => {
    setSelectedInterests((current) => current.includes(value) ? current.filter((item) => item !== value) : [...current, value]);
  };

  const updatePreference = (key: keyof Preferences, value: string) => {
    setPreferences((current) => ({ ...current, [key]: value }));
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setAttempted(true);
    if (requiredComplete && !dateError) {
      setRequestError('');
      setIsGenerating(true);
      try {
        const response = await fetch('/api/travel-plans', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
          destinations,
          startDate,
          endDate,
          travelStyles: selectedInterests,
          interests: selectedInterests,
          budget,
          transportation,
          travelers: preferences.travelers,
          preferences,
          }),
        });
        const data = await response.json() as TravelPlan | { error?: string };
        if (!response.ok) {
          throw new Error('error' in data && data.error ? data.error : 'Plan oluşturulurken bir hata oluştu.');
        }
        setPlan(data as TravelPlan);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } catch {
        setRequestError('Plan oluşturulurken bir hata oluştu. Lütfen tekrar deneyin.');
      } finally {
        setIsGenerating(false);
      }
    }
  };

  const inputClass = (hasError = false) => `h-12 w-full rounded-[13px] border bg-[#fbfaf5] px-4 text-[13px] text-[#164b4a] outline-none transition placeholder:text-[#9aac9f] focus:border-[#26726a] focus:ring-4 focus:ring-[#26726a]/10 ${hasError ? 'border-[#d66f4e] bg-[#fff7f1]' : 'border-[#dddccf]'}`;

  if (plan) {
    return <TravelPlanResult plan={plan} onBack={() => { setPlan(null); setAttempted(false); setRequestError(''); window.scrollTo({ top: 0, behavior: 'smooth' }); }} />;
  }

  return (
    <main className="paper-grain min-h-[100dvh] overflow-hidden bg-[#f4f1e7]">
      <header className="relative z-10 mx-auto flex max-w-[1260px] items-center justify-between px-5 py-5 sm:px-8 lg:px-12">
        <Logo />
        <nav className="hidden items-center gap-8 text-[12px] font-semibold text-[#628078] md:flex" aria-label="Ana menü">
          <a href="#planlayici" className="transition hover:text-[#164b4a]" data-testid="link-planlayici">Planlayıcı</a>
          <a href="#nasil-calisir" className="transition hover:text-[#164b4a]" data-testid="link-nasil-calisir">Nasıl çalışır?</a>
          <span className="flex items-center gap-2 rounded-full border border-[#d5ded2] bg-[#edf1e7] px-3 py-2 text-[11px] text-[#508078]">
            <span className="size-1.5 rounded-full bg-[#5aa878]" /> İlk sürüm
          </span>
        </nav>
        <button type="button" className="flex items-center gap-2 rounded-full border border-[#d5ded2] px-3 py-2 text-[11px] font-semibold text-[#376963] transition hover:border-[#26726a] md:hidden" data-testid="button-mobile-menu">
          <Route size={14} /> Menü
        </button>
      </header>

      <section className="relative mx-auto max-w-[1260px] px-5 pb-12 pt-7 sm:px-8 lg:px-12 lg:pb-20 lg:pt-14">
        <div className="pointer-events-none absolute -right-16 top-0 hidden size-[270px] rounded-full border border-[#b7cec0]/50 lg:block" />
        <div className="pointer-events-none absolute -right-3 top-10 hidden size-[210px] rounded-full border border-[#b7cec0]/50 lg:block" />
        <div className="pointer-events-none absolute right-20 top-16 hidden size-[120px] rounded-full bg-[#e5ebd9]/70 lg:block" />
        <div className="grid items-start gap-12 lg:grid-cols-[minmax(300px,0.7fr)_minmax(560px,1.3fr)] lg:gap-20">
          <div className="animate-float-in pt-2 lg:sticky lg:top-8">
            <div className="mb-6 flex items-center gap-3 font-mono-ui text-[10px] uppercase tracking-[0.2em] text-[#c26b50]">
              <span className="h-px w-8 bg-[#d66f4e]" /> Yeni bir rota başlıyor
            </div>
            <h1 className="max-w-[500px] font-display text-[clamp(42px,6vw,75px)] font-bold leading-[0.94] tracking-[-0.065em] text-[#164b4a]">
              Aklındaki yolculuğa<br />
              <span className="text-[#d66f4e]">bir yön ver.</span>
            </h1>
            <p className="mt-7 max-w-[395px] text-[15px] leading-7 text-[#5f7770]">
              Nerede olmak istediğini söyle. Yolüstü, seyahatin için iyi bir başlangıç fikrini birlikte netleştirsin.
            </p>
            <div className="mt-10 flex items-center gap-4">
              <div className="relative flex size-12 items-center justify-center rounded-full border border-[#c7d7c9] bg-[#e7eee2] text-[#26726a]">
                <Navigation size={19} />
                <span className="absolute -right-1 -top-1 flex size-4 items-center justify-center rounded-full bg-[#f5cf55] text-[8px] font-bold text-[#164b4a]">1</span>
              </div>
              <div className="text-[12px] leading-5 text-[#6a817b]">
                <strong className="block text-[#365957]">Kısa ve kişisel</strong>
                Sadece sana uygun olanı seç.
              </div>
            </div>
            <div className="mt-12 hidden items-center gap-3 lg:flex" id="nasil-calisir">
              <div className="h-px w-12 bg-[#bdcec2]" />
              <span className="font-mono-ui text-[10px] uppercase tracking-[0.14em] text-[#78918a]">Sen seç · biz düzenleyelim</span>
            </div>
          </div>

          <form id="planlayici" onSubmit={handleSubmit} className="animate-float-in relative rounded-[26px] border border-[#d8ded1] bg-[#faf9f3] p-5 shadow-[var(--shadow-soft)] [animation-delay:120ms] sm:p-8 lg:p-10">
            <div className="mb-8 flex items-center justify-between border-b border-[#e2e4d9] pb-5">
              <div>
                <div className="font-mono-ui text-[10px] uppercase tracking-[0.17em] text-[#78918a]">Seyahat özeti</div>
                <div className="mt-1 font-display text-[17px] font-bold text-[#164b4a]">Rota fikrini anlat</div>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-mono-ui text-[11px] text-[#64817a]" data-testid="text-completion">{completionCount}/5</span>
                <div className="h-1.5 w-16 overflow-hidden rounded-full bg-[#e3e6dc]">
                  <div className="h-full rounded-full bg-[#d66f4e] transition-all duration-500" style={{ width: `${completionCount * 20}%` }} />
                </div>
              </div>
            </div>

            <div className="space-y-10">
              <section>
                <SectionHeading number="01" eyebrow="Nereye?" title="Haritada bir yer seç" hint="Birden fazla durak ekleyebilirsin." />
                <FieldLabel required>Ülke veya şehir</FieldLabel>
                <div className={`flex h-12 items-center gap-2 rounded-[13px] border bg-[#fbfaf5] px-3 transition focus-within:border-[#26726a] focus-within:ring-4 focus-within:ring-[#26726a]/10 ${attempted && destinations.length === 0 ? 'border-[#d66f4e] bg-[#fff7f1]' : 'border-[#dddccf]'}`}>
                  <MapPin size={17} className="ml-1 shrink-0 text-[#6d9b8d]" />
                  <input
                    value={destinationInput}
                    onChange={(event) => setDestinationInput(event.target.value)}
                    onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); addDestination(); } }}
                    placeholder="Örn. İzmir, Portekiz..."
                    className="h-full min-w-0 flex-1 bg-transparent text-[13px] text-[#164b4a] outline-none placeholder:text-[#9aac9f]"
                    data-testid="input-destination"
                    aria-label="Ülke veya şehir"
                  />
                  <button type="button" onClick={addDestination} className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-[#e7eee2] text-[#26726a] transition hover:bg-[#d6e4d9]" data-testid="button-add-destination" aria-label="Destinasyon ekle">
                    <Plus size={17} />
                  </button>
                </div>
                {destinations.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2" data-testid="list-destinations">
                    {destinations.map((destination) => (
                      <span key={destination} className="animate-grow-in inline-flex items-center gap-2 rounded-full border border-[#b9d3c4] bg-[#e4f0e9] py-1.5 pl-3 pr-1.5 text-[12px] font-semibold text-[#26726a]">
                        {destination}
                        <button type="button" onClick={() => removeDestination(destination)} className="flex size-5 items-center justify-center rounded-full text-[#56907f] transition hover:bg-[#c8e0d0] hover:text-[#164b4a]" data-testid={`button-remove-destination-${destination.replace(/\s+/g, '-').toLowerCase()}`} aria-label={`${destination} durağını kaldır`}>
                          <X size={13} />
                        </button>
                      </span>
                    ))}
                  </div>
                )}
                {attempted && destinations.length === 0 && <p className="mt-2 flex items-center gap-1.5 text-[11px] text-[#c25e48]"><CircleAlert size={13} /> En az bir durak ekle.</p>}
              </section>

              <section>
                <SectionHeading number="02" eyebrow="Ne zaman?" title="Takvime bir aralık bırak" hint="Tarihler kesin değilse yaklaşık bir aralık da olur." />
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <FieldLabel required>Başlangıç</FieldLabel>
                    <div className="relative">
                      <CalendarDays size={16} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#6d9b8d]" />
                      <input type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} className={`${inputClass(attempted && !startDate)} pl-11`} data-testid="input-start-date" aria-label="Başlangıç tarihi" />
                    </div>
                  </div>
                  <div>
                    <FieldLabel required>Bitiş</FieldLabel>
                    <div className="relative">
                      <CalendarDays size={16} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#6d9b8d]" />
                      <input type="date" min={startDate || undefined} value={endDate} onChange={(event) => setEndDate(event.target.value)} className={`${inputClass(attempted && (!endDate || dateError))} pl-11`} data-testid="input-end-date" aria-label="Bitiş tarihi" />
                    </div>
                  </div>
                </div>
                {attempted && dateError && <p className="mt-2 flex items-center gap-1.5 text-[11px] text-[#c25e48]"><CircleAlert size={13} /> Bitiş tarihi başlangıçtan sonra olmalı.</p>}
              </section>

              <section>
                <SectionHeading number="03" eyebrow="Nasıl bir yol?" title="Seni en çok ne çağırıyor?" hint="Birden fazla seçenek seçebilirsin." />
                <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                  {interests.map((interest) => {
                    const selected = selectedInterests.includes(interest.value);
                    return (
                      <button type="button" key={interest.value} onClick={() => toggleInterest(interest.value)} aria-pressed={selected} data-testid={`button-interest-${interest.value}`} className={`flex min-h-[52px] items-center gap-2 rounded-[13px] border px-3 text-left text-[12px] font-semibold transition duration-200 ${selected ? 'border-[#26726a] bg-[#e4f0e9] text-[#26726a] shadow-[inset_0_0_0_1px_#26726a]' : 'border-[#dddccf] bg-[#fbfaf5] text-[#55736c] hover:-translate-y-0.5 hover:border-[#8eaea0]'}`}>
                        <span className={`flex size-4 shrink-0 items-center justify-center rounded-full border ${selected ? 'border-[#26726a] bg-[#26726a] text-[#fff8ea]' : 'border-[#b8c9be] text-transparent'}`}><Check size={10} strokeWidth={3} /></span>
                        {interest.label}
                      </button>
                    );
                  })}
                </div>
                {attempted && selectedInterests.length === 0 && <p className="mt-2 flex items-center gap-1.5 text-[11px] text-[#c25e48]"><CircleAlert size={13} /> En az bir ilgi alanı seç.</p>}
              </section>

              <section>
                <SectionHeading number="04" eyebrow="Bütçe" title="Ritmini belirle" hint="Yaklaşık bir tercih yeterli." />
                <div className="grid gap-2.5 sm:grid-cols-3">
                  {budgets.map((option) => <ChoiceButton key={option.value} {...option} selected={budget === option.value} onClick={() => setBudget(option.value)} testId={`button-budget-${option.value}`} icon={<WalletCards size={17} />} />)}
                </div>
                {attempted && !budget && <p className="mt-2 flex items-center gap-1.5 text-[11px] text-[#c25e48]"><CircleAlert size={13} /> Bir bütçe ritmi seç.</p>}
              </section>

              <section>
                <SectionHeading number="05" eyebrow="Ulaşım" title="Yolda nasıl ilerleyelim?" />
                <div className="grid gap-2.5 sm:grid-cols-3">
                  {transport.map((option) => <ChoiceButton key={option.value} {...option} selected={transportation === option.value} onClick={() => setTransportation(option.value)} testId={`button-transport-${option.value}`} icon={option.value === 'yuruyus' ? <Footprints size={17} /> : option.value === 'toplu' ? <TrainFront size={17} /> : <BusFront size={17} />} />)}
                </div>
                {attempted && !transportation && <p className="mt-2 flex items-center gap-1.5 text-[11px] text-[#c25e48]"><CircleAlert size={13} /> Bir ulaşım tercihi seç.</p>}
              </section>

              <section className="border-t border-[#e2e4d9] pt-7">
                <button type="button" onClick={() => setShowPreferences((current) => !current)} className="flex w-full items-center justify-between text-left" aria-expanded={showPreferences} data-testid="button-toggle-preferences">
                  <span>
                    <span className="flex items-center gap-2 font-display text-[17px] font-bold text-[#164b4a]"><Sparkles size={16} className="text-[#d66f4e]" /> Birkaç küçük tercih <span className="font-sans text-[11px] font-medium text-[#78918a]">(isteğe bağlı)</span></span>
                    <span className="mt-1 block text-[12px] text-[#78918a]">Planı sana biraz daha yaklaştır.</span>
                  </span>
                  <span className={`flex size-8 items-center justify-center rounded-full bg-[#e7eee2] text-[#26726a] transition-transform ${showPreferences ? 'rotate-180' : ''}`}><ChevronDown size={17} /></span>
                </button>
                {showPreferences && (
                  <div className="animate-float-in mt-6 grid gap-5 sm:grid-cols-2">
                    <div>
                      <FieldLabel><Users size={14} className="text-[#6d9b8d]" /> Kaç kişisiniz?</FieldLabel>
                      <div className="relative">
                        <Users size={15} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#6d9b8d]" />
                        <select value={preferences.travelers} onChange={(event) => updatePreference('travelers', event.target.value)} className={`${inputClass()} appearance-none pl-11`} data-testid="select-travelers">
                          <option value="1">1 kişi</option><option value="2">2 kişi</option><option value="3">3 kişi</option><option value="4+">4+ kişi</option>
                        </select>
                        <ChevronDown size={15} className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-[#6d9b8d]" />
                      </div>
                    </div>
                    <div>
                      <FieldLabel><BedDouble size={14} className="text-[#6d9b8d]" /> Konaklama</FieldLabel>
                      <div className="relative">
                        <BedDouble size={15} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#6d9b8d]" />
                        <select value={preferences.accommodation} onChange={(event) => updatePreference('accommodation', event.target.value)} className={`${inputClass()} appearance-none pl-11`} data-testid="select-accommodation">
                          <option value="">Fark etmez</option><option value="otel">Otel</option><option value="butik">Butik konaklama</option><option value="ev">Daire / ev</option>
                        </select>
                        <ChevronDown size={15} className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-[#6d9b8d]" />
                      </div>
                    </div>
                    <div>
                      <FieldLabel><Clock3 size={14} className="text-[#6d9b8d]" /> Güne başlama</FieldLabel>
                      <div className="relative">
                        <SunMedium size={15} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#d49745]" />
                        <input type="time" value={preferences.startTime} onChange={(event) => updatePreference('startTime', event.target.value)} className={`${inputClass()} pl-11`} data-testid="input-start-time" />
                      </div>
                    </div>
                    <div>
                      <FieldLabel><Moon size={14} className="text-[#6d9b8d]" /> Günü bitirme</FieldLabel>
                      <div className="relative">
                        <Moon size={15} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#6d9b8d]" />
                        <input type="time" value={preferences.endTime} onChange={(event) => updatePreference('endTime', event.target.value)} className={`${inputClass()} pl-11`} data-testid="input-end-time" />
                      </div>
                    </div>
                    <div className="sm:col-span-2">
                      <FieldLabel><Footprints size={14} className="text-[#6d9b8d]" /> Yürüme iştahı</FieldLabel>
                      <div className="grid grid-cols-3 gap-2">
                        {[['az', 'Az yürüyüş'], ['orta', 'Dengeli'], ['cok', 'Bol bol yürüyüş']].map(([value, label]) => <button key={value} type="button" onClick={() => updatePreference('walking', value)} className={`rounded-[11px] border py-2.5 text-[11px] font-semibold transition ${preferences.walking === value ? 'border-[#26726a] bg-[#e4f0e9] text-[#26726a]' : 'border-[#dddccf] bg-[#fbfaf5] text-[#64817a] hover:border-[#8eaea0]'}`} data-testid={`button-walking-${value}`}>{label}</button>)}
                      </div>
                    </div>
                  </div>
                )}
              </section>
            </div>

            {isGenerating && (
              <div className="mt-8 flex items-center gap-3 rounded-[15px] border border-[#d6dcae] bg-[#fff8dc] p-4 text-[#9e791b]" role="status" data-testid="status-loading">
                <span className="size-5 animate-spin rounded-full border-2 border-[#d6dcae] border-t-[#c26b50]" />
                <div>
                  <div className="text-[13px] font-bold">Seyahat planın hazırlanıyor...</div>
                  <p className="mt-1 text-[12px] text-[#a68c3c]">Seçimlerini anlamlı bir rotaya dönüştürüyoruz.</p>
                </div>
              </div>
            )}
            {requestError && (
              <div className="mt-8 flex items-start gap-3 rounded-[15px] border border-[#edc7bb] bg-[#fff1eb] p-4 text-[#b9553e]" role="alert" data-testid="status-error">
                <CircleAlert size={18} className="mt-0.5 shrink-0" />
                <div>
                  <div className="text-[13px] font-bold">{requestError}</div>
                  <p className="mt-1 text-[12px] text-[#c26b50]">Bilgilerini değiştirmeden tekrar deneyebilirsin.</p>
                </div>
              </div>
            )}
            <div className="mt-8 border-t border-[#e2e4d9] pt-6">
              <button type="submit" disabled={isGenerating} className="group flex h-14 w-full items-center justify-center gap-3 rounded-[14px] bg-[#164b4a] px-6 text-[14px] font-bold text-[#f8f3e3] shadow-[0_8px_0_#c9d7c5] transition duration-200 hover:-translate-y-0.5 hover:bg-[#236660] active:translate-y-1 active:shadow-none disabled:cursor-wait disabled:opacity-70" data-testid="button-submit">
                {isGenerating ? 'Plan hazırlanıyor...' : 'Seyahatimi Planla'} <ArrowRight size={18} className="transition-transform duration-200 group-hover:translate-x-1" />
              </button>
              <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-[10px] text-[#8a9d94]"><Info size={12} /> Seçimlerine göre kişisel bir rota taslağı oluşturuyoruz.</p>
            </div>
          </form>
        </div>
      </section>

      <footer className="mx-auto flex max-w-[1260px] flex-col gap-4 border-t border-[#d9ded2] px-5 py-7 text-[11px] text-[#78918a] sm:flex-row sm:items-center sm:justify-between sm:px-8 lg:px-12">
        <div className="flex items-center gap-2"><Heart size={13} className="text-[#d66f4e]" /> İyi yolculuklar, iyi fikirler.</div>
        <div className="font-mono-ui text-[10px] uppercase tracking-[0.13em]">yolüstü / faz 01</div>
      </footer>

      <div className="fixed bottom-0 left-0 right-0 z-10 border-t border-[#d8ded1] bg-[#f4f1e7]/95 p-3 backdrop-blur-md sm:hidden">
        <button type="button" onClick={() => document.getElementById('planlayici')?.scrollIntoView({ behavior: 'smooth', block: 'start' })} className="flex h-12 w-full items-center justify-center gap-2 rounded-[13px] bg-[#164b4a] text-[13px] font-bold text-[#f8f3e3] shadow-[0_5px_0_#c9d7c5]" data-testid="button-mobile-start">
          <Navigation size={16} /> Seyahatini anlat
        </button>
      </div>
    </main>
  );
}

export default Home;
