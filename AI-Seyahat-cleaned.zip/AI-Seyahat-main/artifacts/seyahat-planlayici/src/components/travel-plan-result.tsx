import {
  ArrowLeft,
  CalendarDays,
  CarFront,
  Check,
  CircleDot,
  Clock3,
  MapPin,
  Navigation,
  Route,
  Sparkles,
  Timer,
} from "lucide-react";
import type { TravelPlan } from "@workspace/api-client-react";

function formatDate(date: string) {
  const parsed = new Date(`${date}T12:00:00`);
  if (Number.isNaN(parsed.getTime())) return date;
  return new Intl.DateTimeFormat("tr-TR", {
    day: "numeric",
    month: "long",
    weekday: "long",
  }).format(parsed);
}

function intensityClass(intensity: string) {
  if (intensity === "Yoğun") {
    return "border-[#edc7bb] bg-[#fff1eb] text-[#b9553e]";
  }
  if (intensity === "Dengeli") {
    return "border-[#f0dfae] bg-[#fff8dc] text-[#9e791b]";
  }
  return "border-[#b8d8c5] bg-[#e8f3e9] text-[#26726a]";
}

export function TravelPlanResult({
  plan,
  onBack,
}: {
  plan: TravelPlan;
  onBack: () => void;
}) {
  return (
    <main className="paper-grain min-h-[100dvh] overflow-hidden bg-[#f4f1e7]">
      <header className="relative z-10 mx-auto flex max-w-[1180px] items-center justify-between px-5 py-5 sm:px-8 lg:px-12">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-[13px] bg-[#f5cf55] text-[#164b4a] shadow-[4px_4px_0_#164b4a]">
            <Navigation size={22} strokeWidth={2.4} />
          </div>
          <div className="leading-none">
            <div className="font-display text-[20px] font-bold tracking-[-0.05em] text-[#164b4a]">yolüstü</div>
            <div className="mt-1 font-mono-ui text-[8px] uppercase tracking-[0.22em] text-[#64817a]">seyahat planın</div>
          </div>
        </div>
        <button type="button" onClick={onBack} className="flex items-center gap-2 rounded-full border border-[#cbd9ce] bg-[#edf1e7] px-4 py-2.5 text-[12px] font-semibold text-[#26726a] transition hover:border-[#26726a]">
          <ArrowLeft size={15} /> Formu düzenle
        </button>
      </header>

      <section className="mx-auto max-w-[1180px] px-5 pb-14 pt-7 sm:px-8 lg:px-12 lg:pt-12">
        <div className="mb-8 max-w-[760px] animate-float-in">
          <div className="mb-4 flex items-center gap-3 font-mono-ui text-[10px] uppercase tracking-[0.2em] text-[#c26b50]">
            <span className="h-px w-8 bg-[#d66f4e]" /> Rotan için ilk taslak
          </div>
          <h1 className="font-display text-[clamp(38px,6vw,70px)] font-bold leading-[0.96] tracking-[-0.065em] text-[#164b4a]">
            {plan.tripSummary.title}
          </h1>
          <p className="mt-5 max-w-[700px] text-[15px] leading-7 text-[#5f7770]">{plan.tripSummary.description}</p>
        </div>

        <div className="grid gap-5 lg:grid-cols-[0.8fr_1.2fr]">
          <aside className="space-y-5">
            <div className="rounded-[22px] border border-[#d8ded1] bg-[#faf9f3] p-5 shadow-[var(--shadow-soft)] sm:p-7">
              <div className="mb-5 flex items-center gap-2 font-mono-ui text-[10px] uppercase tracking-[0.17em] text-[#78918a]">
                <Sparkles size={14} className="text-[#d66f4e]" /> Seyahat özeti
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-[15px] bg-[#edf1e7] p-4">
                  <CalendarDays size={17} className="mb-3 text-[#26726a]" />
                  <div className="font-display text-2xl font-bold text-[#164b4a]">{plan.tripSummary.totalDays}</div>
                  <div className="mt-1 text-[11px] text-[#78918a]">gün</div>
                </div>
                <div className="rounded-[15px] bg-[#fff5d3] p-4">
                  <MapPin size={17} className="mb-3 text-[#c26b50]" />
                  <div className="font-display text-2xl font-bold text-[#164b4a]">{plan.tripSummary.cities.length}</div>
                  <div className="mt-1 text-[11px] text-[#78918a]">şehir</div>
                </div>
              </div>
              <div className="mt-5 border-t border-[#e2e4d9] pt-5">
                <div className="mb-3 text-[11px] font-semibold uppercase tracking-[0.12em] text-[#78918a]">Ülkeler</div>
                <div className="flex flex-wrap gap-2">
                  {plan.tripSummary.countries.map((country) => (
                    <span key={country} className="rounded-full border border-[#c4d9c9] bg-[#e4f0e9] px-3 py-1.5 text-[11px] font-semibold text-[#26726a]">{country}</span>
                  ))}
                </div>
              </div>
              <div className="mt-5 border-t border-[#e2e4d9] pt-5">
                <div className="mb-3 text-[11px] font-semibold uppercase tracking-[0.12em] text-[#78918a]">Şehir sırası</div>
                <div className="space-y-2">
                  {plan.route.map((stop) => (
                    <div key={`${stop.order}-${stop.city}`} className="flex items-center gap-3 text-[13px] font-semibold text-[#365957]">
                      <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-[#164b4a] font-mono-ui text-[10px] text-[#f8f3e3]">{stop.order}</span>
                      <span>{stop.city}</span>
                      {stop.order < plan.route.length && <Route size={14} className="ml-auto text-[#9eb6a8]" />}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="rounded-[22px] border border-[#b8d8c5] bg-[#e8f3e9] p-5 text-[#26726a] sm:p-6">
              <div className="flex gap-3">
                <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-[#26726a] text-[#f8f3e3]"><Check size={17} strokeWidth={3} /></div>
                <div>
                  <div className="text-[13px] font-bold">Planın hazır.</div>
                  <p className="mt-1 text-[12px] leading-5 text-[#508078]">Bu taslak, seçimlerine göre AI tarafından oluşturuldu. Gerçek zamanlı çalışma saatleri ve ücretleri ayrıca kontrol etmeni öneririz.</p>
                </div>
              </div>
            </div>
          </aside>

          <div className="space-y-5">
            <div className="flex items-center gap-3 px-1">
              <div className="flex size-9 items-center justify-center rounded-xl bg-[#164b4a] text-[#f8f3e3]"><Route size={17} /></div>
              <div>
                <div className="font-display text-[20px] font-bold text-[#164b4a]">Günlük akış</div>
                <div className="text-[12px] text-[#78918a]">Duraklarını kendi ritminde keşfet.</div>
              </div>
            </div>
            {plan.days.map((day, index) => (
              <article key={`${day.date}-${day.city}-${index}`} className="animate-float-in rounded-[22px] border border-[#d8ded1] bg-[#faf9f3] p-5 shadow-[var(--shadow-soft)] sm:p-7" style={{ animationDelay: `${index * 70}ms` }}>
                <div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#e2e4d9] pb-5">
                  <div>
                    <div className="font-mono-ui text-[10px] uppercase tracking-[0.15em] text-[#c26b50]">{formatDate(day.date)}</div>
                    <h2 className="mt-1 flex items-center gap-2 font-display text-[22px] font-bold tracking-[-0.035em] text-[#164b4a]"><MapPin size={18} className="text-[#6d9b8d]" /> {day.city}</h2>
                  </div>
                  <span className={`rounded-full border px-3 py-1.5 text-[11px] font-bold ${intensityClass(day.intensity)}`}>{day.intensity}</span>
                </div>
                <div className="mt-5 space-y-1">
                  {day.activities.map((activity, activityIndex) => (
                    <div key={`${activity.time}-${activity.name}-${activityIndex}`} className="group grid grid-cols-[54px_18px_1fr] gap-3 py-3">
                      <div className="pt-0.5 font-mono-ui text-[11px] font-semibold text-[#26726a]">{activity.time}</div>
                      <div className="relative flex justify-center">
                        <span className="relative z-[1] mt-1.5 size-2 rounded-full bg-[#d66f4e] ring-4 ring-[#fff0e8]" />
                        {activityIndex < day.activities.length - 1 && <span className="absolute top-4 h-full w-px bg-[#d8e2d8]" />}
                      </div>
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-semibold text-[13px] text-[#365957]">{activity.name}</span>
                          <span className="rounded-full bg-[#edf1e7] px-2 py-0.5 text-[9px] font-semibold uppercase tracking-[0.06em] text-[#78918a]">{activity.category}</span>
                        </div>
                        <p className="mt-1 max-w-[560px] text-[12px] leading-5 text-[#78918a]">{activity.description}</p>
                        <div className="mt-2 flex items-center gap-1 text-[10px] font-medium text-[#9aac9f]"><Timer size={12} /> {activity.durationMinutes} dakika</div>
                      </div>
                    </div>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
      <footer className="mx-auto flex max-w-[1180px] items-center justify-between border-t border-[#d9ded2] px-5 py-7 text-[11px] text-[#78918a] sm:px-8 lg:px-12">
        <span className="flex items-center gap-2"><CarFront size={13} className="text-[#d66f4e]" /> Ulaşım tercihin: plana işlendi.</span>
        <span className="flex items-center gap-2 font-mono-ui uppercase tracking-[0.13em]"><CircleDot size={11} /> yolüstü / faz 02</span>
      </footer>
    </main>
  );
}