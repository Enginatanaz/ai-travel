import type { TravelPlan, TravelPlanRequest } from "@workspace/api-zod";

const GEMINI_MODEL = "gemini-2.5-flash";
const GEMINI_ENDPOINT = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

type AiServiceErrorCode = "missing_api_key" | "upstream_error" | "invalid_response";

export class AiServiceError extends Error {
  constructor(
    public readonly code: AiServiceErrorCode,
    message: string,
    options?: ErrorOptions,
  ) {
    super(message, options);
    this.name = "AiServiceError";
  }
}

const responseSchema = {
  type: "OBJECT",
  properties: {
    tripSummary: {
      type: "OBJECT",
      properties: {
        title: { type: "STRING" },
        description: { type: "STRING" },
        countries: { type: "ARRAY", items: { type: "STRING" } },
        cities: { type: "ARRAY", items: { type: "STRING" } },
        totalDays: { type: "INTEGER" },
      },
      required: ["title", "description", "countries", "cities", "totalDays"],
    },
    route: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: {
          city: { type: "STRING" },
          order: { type: "INTEGER" },
        },
        required: ["city", "order"],
      },
    },
    days: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: {
          date: { type: "STRING" },
          city: { type: "STRING" },
          intensity: {
            type: "STRING",
            enum: ["Rahat", "Dengeli", "Yoğun"],
          },
          activities: {
            type: "ARRAY",
            items: {
              type: "OBJECT",
              properties: {
                time: { type: "STRING" },
                name: { type: "STRING" },
                category: { type: "STRING" },
                durationMinutes: { type: "INTEGER" },
                description: { type: "STRING" },
              },
              required: [
                "time",
                "name",
                "category",
                "durationMinutes",
                "description",
              ],
            },
          },
        },
        required: ["date", "city", "intensity", "activities"],
      },
    },
  },
  required: ["tripSummary", "route", "days"],
};

function buildPrompt(request: TravelPlanRequest): string {
  const startDate = request.startDate.toISOString().slice(0, 10);
  const endDate = request.endDate.toISOString().slice(0, 10);

  return `Aşağıdaki seyahat brief'i için uygulanabilir, gerçekçi ve Türkçe bir seyahat planı oluştur.

Kullanıcı brief'i:
${JSON.stringify({
  destinations: request.destinations,
  startDate,
  endDate,
  travelStyles: request.travelStyles,
  interests: request.interests,
  budget: request.budget,
  transportation: request.transportation,
  travelers: request.travelers,
  preferences: request.preferences,
})}

Kurallar:
- Yalnızca geçerli JSON döndür; markdown, açıklama veya kod bloğu kullanma.
- Şehirleri kullanıcı destinasyonlarına göre seç; şehir sırasını ulaşım şekli ve coğrafi mantıkla belirle.
- Tarih aralığındaki her gün için bir day girdisi üret.
- Günleri aşırı doldurma. Ulaşım, öğün ve dinlenme için zaman bırak.
- Aktivite sürelerini dakika cinsinden tam sayı ver.
- "Rahat", "Dengeli" veya "Yoğun" yoğunluk değerlerinden birini kullan.
- Gerçek zamanlı veri, güncel çalışma saati, kesin ücret veya doğrulanmamış puan uydurma.
- Bilinmeyen bilgileri kesin gerçek gibi sunma; genel ve uygulanabilir öneriler yaz.
- Tarihler ${startDate} ile ${endDate} arasındaki tüm günleri kapsamalı.
- Çıktı şeması tripSummary, route ve days alanlarından oluşmalı.`;
}

function extractJson(text: string): string {
  const trimmed = text.trim();
  if (trimmed.startsWith("```")) {
    return trimmed
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/, "")
      .trim();
  }
  return trimmed;
}

export async function generateTravelPlan(
  request: TravelPlanRequest,
): Promise<TravelPlan> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new AiServiceError(
      "missing_api_key",
      "GEMINI_API_KEY is not configured.",
    );
  }

  let response: Response;
  try {
    response = await fetch(`${GEMINI_ENDPOINT}?key=${encodeURIComponent(apiKey)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: {
          parts: [
            {
              text: "Sen gerçekçi seyahat programları hazırlayan bir seyahat planlama asistanısın. Yanıtlarını yalnızca istenen JSON şemasına uygun üret.",
            },
          ],
        },
        contents: [{ role: "user", parts: [{ text: buildPrompt(request) }] }],
        generationConfig: {
          temperature: 0.35,
          responseMimeType: "application/json",
          responseSchema,
          maxOutputTokens: 8192,
        },
      }),
    });
  } catch (error) {
    throw new AiServiceError(
      "upstream_error",
      "Gemini API request failed.",
      { cause: error },
    );
  }

  if (!response.ok) {
    throw new AiServiceError(
      "upstream_error",
      `Gemini API returned ${response.status}.`,
    );
  }

  let payload: {
    candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
  };
  try {
    payload = (await response.json()) as typeof payload;
  } catch (error) {
    throw new AiServiceError("invalid_response", "Gemini response was not JSON.", {
      cause: error,
    });
  }

  const rawText = payload.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!rawText) {
    throw new AiServiceError(
      "invalid_response",
      "Gemini response did not contain a travel plan.",
    );
  }

  try {
    const parsed = JSON.parse(extractJson(rawText));
    const { GenerateTravelPlanResponse } = await import("@workspace/api-zod");
    return GenerateTravelPlanResponse.parse(parsed) as TravelPlan;
  } catch (error) {
    throw new AiServiceError(
      "invalid_response",
      "Gemini returned an invalid travel plan.",
      { cause: error },
    );
  }
}